/**
 * Funcion que ejecuta la peticion AJAX para recoger el JSON
 */

var plantasInterior;
var hayError = false;
var Plantas = [];
var arrPlantasInt = [];
var PlantaOb;
//d3.selectAll(".myCheckbox").on("change", update);
//update();


$(document).ready(function() {


    ejecutarLlamadaAjax();
    chequeoFlor();
    chequeoLuz();




});

function chequeoFlor() {
    var checkbox1 = document.getElementById("siFlor");
    var checkbox2 = document.getElementById("noFlor");
    checkbox1.onclick = function() {
        if (checkbox1.checked != false) {
            checkbox2.checked = null;
        }
    }
    checkbox2.onclick = function() {
        if (checkbox2.checked != false) {
            checkbox1.checked = null;
        }
    }
}
function chequeoLuz() {
    var checkbox1 = document.getElementById("siLuz");
    var checkbox2 = document.getElementById("noLuz");
    checkbox1.onclick = function() {
        if (checkbox1.checked != false) {
            checkbox2.checked = null;
        }
    }
    checkbox2.onclick = function() {
        if (checkbox2.checked != false) {
            checkbox1.checked = null;
        }
    }
}

function Validar() {
    mostrarError("");
    hayError = false;
    validarFlor();
    validarLuz();
    if (hayError == false) {

        //Checked de si tiene flor o no
        var flor;
        if (document.querySelector("#siFlor").checked) {
            flor = "si";
        } else {
            flor = "no";
        }

    }
}
function validarFlor() {
    var selFlor = document.getElementsByName("Flor");
    for (var i = 0; i < selFlor.length; i++) {
        if (selFlor[i].checked) {
            return;
        }
    }
    mostrarError("Seleccione si la planta que desea debe tener flor o no");
}
function validarLuz() {
    var selLuz = document.getElementsByName("luz");
    for (var i = 0; i < selLuz.length; i++) {
        if (selLuz[i].checked) {
            return;
        }
    }
    mostrarError("Seleccione si la planta necesita luz directa o no");
}


function mostrarError(texto, elemento) {
    document.getElementById("mensajeError").innerHTML = texto;
    if (elemento != null) {
        elemento.focus();
    }
    hayError = true;
}
function ejecutarLlamadaAjax() {
    var peticion = new XMLHttpRequest();
    peticion.onreadystatechange = function() {
        if (peticion.readyState == 4 && peticion.status == 200) {
            plantasInterior = JSON.parse(peticion.responseText);
            guardarInformacion(plantasInterior);
            crearTabla(arrPlantasInt);
            //console.log(plantasInterior);
        } else {
            //alert("La base de datos no está disponible en estos momentos");
        }
    }
    peticion.overrideMimeType("text/plain");
    peticion.open("GET", "https://raw.githubusercontent.com/carolsanz96/plantasInterior.json/master/PlantasInterior.json");
    peticion.send(null);


}
/**
 * Función que guarda la información del Json en un Array de clases Series
 * @param {JSON} plantasInterior 
 */

function guardarInformacion(plantasInterior) {

    var plantaJson = plantasInterior.plantasInterior;


    for (i = 0; i < plantaJson.length; i++) {
        var nombre = plantaJson[i].nombre;
        var codin = plantaJson[i].codin;
        var precio = plantaJson[i].precio;
        var oferta = plantaJson[i].oferta;
        var arrUbicaciones = new Array();
        for (j = 0; j < plantaJson[i].ubicacion.length; j++) {
            var ubicacion = plantaJson[i].ubicacion[j].lugar;
            arrUbicaciones.push(ubicacion);
        }
        console.log(plantaJson[i].ubicacion);
        var flor = plantaJson[i].flor;
        var cuidados = plantaJson[i].cuidados;
        var luzdir = plantaJson[i].luzdir;
        var luzindir = plantaJson[i].luzindir;
        var url = plantaJson[i].url;
        PlantaOb = new PlantaInterior(nombre, codin, precio, oferta, arrUbicaciones, flor, cuidados, luzdir, luzindir, url);


        arrPlantasInt.push(PlantaOb);
    }
    //console.log(plantasForm);
}
/**
 * Funcion que crea la Tabla de HTML en la que se le pasa un array de clases Serie
 * @param {Array} arrPlantasInt  Array de clases Plantas
 */

function crearTabla(arrPlantasInt) {
    //Este 'divMostrar' Sirve para meterlo todo dentro de un div independiente de la tabla ya creada con el formulario
    var divMostrar = document.getElementById("mostrar");
    divMostrar.innerHTML = "";
    var table = document.createElement("table");
    table.id = "tabla_flores";
    table.setAttribute("border", "1");
    var trCabecera = document.createElement("tr");
    var tdC1 = document.createElement("td");
    var tdC2 = document.createElement("td");
    var tdC3 = document.createElement("td");
    var tdC4 = document.createElement("td");
    var tdC5 = document.createElement("td");
    var tdC6 = document.createElement("td");
    var tdC7 = document.createElement("td");
    var tdC8 = document.createElement("td");
    var tdC9 = document.createElement("td");
    var tdC10 = document.createElement("td");


    var tnC1 = document.createTextNode("Nombre");
    var tnC2 = document.createTextNode("Codin");
    var tnC3 = document.createTextNode("Precio");
    var tnC4 = document.createTextNode("Oferta");
    var tnC5 = document.createTextNode("Ubicación");

    var tnC6 = document.createTextNode("Flor");
    var tnC7 = document.createTextNode("Cuidados");
    var tnC8 = document.createTextNode("Luz Directa");
    var tnC9 = document.createTextNode("Luz Indirecta");
    var tnC10 = document.createTextNode("Url");




    tdC1.appendChild(tnC1);
    tdC2.appendChild(tnC2);
    tdC3.appendChild(tnC3);
    tdC4.appendChild(tnC4);
    tdC5.appendChild(tnC5);
    tdC6.appendChild(tnC6);
    tdC7.appendChild(tnC7);
    tdC8.appendChild(tnC8);
    tdC9.appendChild(tnC9);
    tdC10.appendChild(tnC10);


    trCabecera.appendChild(tdC1);
    trCabecera.appendChild(tdC2);
    trCabecera.appendChild(tdC3);
    trCabecera.appendChild(tdC4);
    trCabecera.appendChild(tdC5);
    trCabecera.appendChild(tdC6);
    trCabecera.appendChild(tdC7);
    trCabecera.appendChild(tdC8);
    trCabecera.appendChild(tdC9);
    trCabecera.appendChild(tdC10);


    table.appendChild(trCabecera);

    if (arrPlantasInt.length != 0) {
        for (let i = 0; i < arrPlantasInt.length; i++) {


            console.log(arrPlantasInt[i].nombre);
            /*console.log(arrPlantasInt[i].codin);
            console.log(arrPlantasInt[i].precio);
            console.log(arrPlantasInt[i].oferta);
            console.log(arrPlantasInt[i].ubicacion);
            console.log(arrPlantasInt[i].flor);
            console.log(arrPlantasInt[i].cuidados);
            console.log(arrPlantasInt[i].luzdir);
            console.log(arrPlantasInt[i].luzindir);
            console.log(arrPlantasInt[i].url);*/

            var tr = document.createElement("tr");
            var td1 = document.createElement("td");
            var td2 = document.createElement("td");
            var td3 = document.createElement("td");
            var td4 = document.createElement("td");
            var td5 = document.createElement("td");
            var td6 = document.createElement("td");
            var td7 = document.createElement("td");
            var td8 = document.createElement("td");
            var td9 = document.createElement("td");
            var td10 = document.createElement("td");
            td10.classList.add('container-img');

            var tn1 = document.createTextNode(arrPlantasInt[i].nombre);
            var tn2 = document.createTextNode(arrPlantasInt[i].codin);
            var tn3 = document.createTextNode(arrPlantasInt[i].precio);
            var tn4 = document.createTextNode(arrPlantasInt[i].oferta);
            //creo otra variable
            var z = 9;
            for (let j = 0; j < arrPlantasInt[i].ubicacion.length; j++) {

                console.log(arrPlantasInt[i].ubicacion[j]);
                var tn5 = document.createTextNode(arrPlantasInt[i].ubicacion);
            }
            var tn6 = document.createTextNode(arrPlantasInt[i].flor);
            var tn7 = document.createTextNode(arrPlantasInt[i].cuidados);
            var tn8 = document.createTextNode(arrPlantasInt[i].luzdir);
            var tn9 = document.createTextNode(arrPlantasInt[i].luzindir);
            //Se crea una variable img para pasarle la url
            var img = document.createElement("img");
            //le pones attribute src y le pasas la url
            img.setAttribute("src", arrPlantasInt[i].url)
            var container = document.createElement('div');
            container.classList.add('nameContainer');
            var enlace = document.createElement('a');
            enlace.text = arrPlantasInt[i].nombre;
            enlace.href = 'https://www.google.es';
            container.appendChild(enlace);

            td1.appendChild(tn1);
            td2.appendChild(tn2);
            td3.appendChild(tn3);
            td4.appendChild(tn4);
            td5.appendChild(tn5);
            td6.appendChild(tn6);
            td7.appendChild(tn7);
            td8.appendChild(tn8);
            td9.appendChild(tn9);
            //lo añades
            td10.appendChild(img);
            td10.appendChild(container);


            tr.appendChild(td1);
            tr.appendChild(td2);
            tr.appendChild(td3);
            tr.appendChild(td4);
            tr.appendChild(td5);
            tr.appendChild(td6);
            tr.appendChild(td7);
            tr.appendChild(td8);
            tr.appendChild(td9);
            tr.appendChild(td10);

            table.appendChild(tr);
            console.log(arrPlantasInt[i].nombre);
            console.log(arrPlantasInt[i].ubicacion);
            console.log(arrPlantasInt[i].flor);

        }
        document.body.appendChild(table);
    }
    console.log("que contiene array de plantas int");
    console.log(document.getElementById('mostrar').innerText);


}
// borra la tabla
function borrarTabla() {
    const tableToDelete = document.getElementById('tabla_flores');
    if (tableToDelete) {
        tableToDelete.parentElement.removeChild(tableToDelete);
    }
}

function filtrarV2(value, nameFilter, arrayAux) {

    return arrayAux.filter(element => {
        if (value === 'selectAll') {
            return true;
        }
        if (Array.isArray(element[nameFilter])) {
            return element[nameFilter].includes(value);
        } else if (typeof element[nameFilter] === 'string') {
            return element[nameFilter] === value;
        } else if (element[nameFilter] === true || element[nameFilter] === false) {
            if (element[nameFilter]) {
                return 'Si' === value;
            } else {
                return 'No' === value;
            }
        }
    });

}
function funcionFiterAll() {
    borrarTabla();
    const allFilters = document.getElementsByClassName('classToFilter');
    const arrayELements = Array.from(allFilters);
    let arrayAux = JSON.parse(JSON.stringify(arrPlantasInt));
    arrayELements.forEach(eleme => {
        const value = eleme.value;
        const filterName = eleme.getAttribute('data-filter');
        arrayAux = filtrarV2(value, filterName, arrayAux);
    });
    crearTabla(arrayAux);
}

//Falla al recorrer la planta obtenida 'plantaOb'
setTimeout(chequeoDatos, 10000);
function filtrar() {
    console.log("En filtrar");
    //console.log(chequeoUbicacion().ubicacionPlanta);

}
